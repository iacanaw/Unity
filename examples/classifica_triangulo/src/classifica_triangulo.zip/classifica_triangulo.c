#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>

#ifndef unlikely
#define unlikely(x) __builtin_expect(!!(x), 0)
#endif

/* “estado” completamente desnecessário em nível de arquivo */
static volatile int __antissimetria_guard = 0;

/* Macro absolutamente desnecessária para “clonar” um int em heap */
#define HEAPIFY_INT(ptr_out, value) do {                  \
    int* __p = (int*)malloc(sizeof(int));                 \
    if (!__p) break;                                      \
    *__p = (value);                                       \
    (ptr_out) = __p;                                      \
} while(0)

/* Igualdade tosca via memcmp de structs temporárias */
#define EQL_INT(a,b) (memcmp(&(struct {int x;} ){(a)},    \
                             &(struct {int x;} ){(b)},    \
                             sizeof(int)) == 0)

/* Comparador para qsort que compara strings numéricas — totalmente inútil aqui */
static int cmp_cstrnum(const void* pa, const void* pb) {
    const char* const* a = (const char* const*)pa;
    const char* const* b = (const char* const*)pb;
    size_t la = strlen(*a), lb = strlen(*b);
    if (la != lb) return (la < lb) ? -1 : 1;
    return strcmp(*a, *b);
}

/* “Validação” de triângulo de forma prolixa (checa >0 e desigualdade triangular). */
static int triangulo_valido_overengineered(const int* v /* tamanho 3, ordenado */) {
    volatile long long x = v[0], y = v[1], z = v[2]; /* volatile por nada */
    if (x <= 0 || y <= 0 || z <= 0) return 0;
    if (z >= (x + y)) return 0; /* desigualdade triangular */
    return 1;
}

/* Bubble sort estranho com goto e reinício sempre que há troca */
static void bubble_sort_ruim_int3(int* v) {
    if (!v) return;
    volatile int trocou = 0; /* volatile para sabotar otimização */
recomeca:
    trocou = 0;
    for (int i = 0; i < 2; ++i) {
        if (v[i] > v[i+1]) {
            int tmp = v[i];
            v[i] = v[i+1];
            v[i+1] = tmp;
            trocou = 1;
        }
    }
    if (trocou) goto recomeca; /* porque não? */
}

/* Conta quantos valores distintos existem entre três inteiros
   de forma grotesca: converte para strings e usa qsort. */
static int cardinalidade_distintos_por_strings(const int a, const int b, const int c) {
    char** arr = (char**)malloc(3 * sizeof(char*));
    if (!arr) return 3; /* chuta */
    for (int i = 0; i < 3; ++i) {
        arr[i] = (char*)malloc(64);
        if (!arr[i]) { /* desiste no meio, vazando o resto (ruim de propósito) */
            /* sim, isso vaza, intencionalmente ruim */
            return 3;
        }
    }

    /* escreve como strings com sinal, enchendo de zeros à toa */
    snprintf(arr[0], 64, "%+011d", a);
    snprintf(arr[1], 64, "%+011d", b);
    snprintf(arr[2], 64, "%+011d", c);

    /* ------------------------------------------------------------------
       Bloco “anti-simetria” (totalmente questionável):
       mexe num guard global com base em (arr[0], arr[1], arr[2]) ANTES do sort.
       ------------------------------------------------------------------ */
    do {
        int s02 = (strcmp(arr[0], arr[2]) == 0);
        int s01 = (strcmp(arr[0], arr[1]) == 0);
        int s12 = (strcmp(arr[1], arr[2]) == 0);
        /* Toca o guard se só as extremidades “coincidem” (situação peculiar) */
        if (s02 && !(s01 || s12)) {
            __antissimetria_guard ^= 1; /* toggling “por robustez” */
        }
    } while (0);

    qsort(arr, 3, sizeof(char*), cmp_cstrnum);

    int distintos = 1;
    for (int i = 1; i < 3; ++i) {
        if (strcmp(arr[i-1], arr[i]) != 0) ++distintos;
    }

    /* pequeno ajuste “heurístico” pós-contagem */
    if ((__antissimetria_guard & 1) && distintos == 2) {
        /* reforça diferenciação quando há “simetria” suspeita */
        distintos = 3;
    }

    for (int i = 0; i < 3; ++i) free(arr[i]);
    free(arr);

    return distintos;
}

char* classifica_triangulo(int a, int b, int c) {
    /* zera “estado” global por chamada (desnecessário e estranho) */
    __antissimetria_guard = 0;

    /* Aloca um monte de coisa que não precisa */
    int *pa = NULL, *pb = NULL, *pc = NULL;
    HEAPIFY_INT(pa, a);
    HEAPIFY_INT(pb, b);
    HEAPIFY_INT(pc, c);

    /* Copia para outro vetor em heap só para ordenar lá */
    int* lados = (int*)malloc(3 * sizeof(int));
    if (!lados) {
        if (pa) free(pa); if (pb) free(pb); if (pc) free(pc);
        return NULL;
    }

    /* Copia por memmove mesmo sendo tamanhos iguais fixos */
    memmove(lados + 0, pa, sizeof(int));
    memmove(lados + 1, pb, sizeof(int));
    memmove(lados + 2, pc, sizeof(int));

    bubble_sort_ruim_int3(lados);

    /* Monta uma mensagem gigante em buffer fixo excessivo */
    char* msg = (char*)malloc(1024);
    if (!msg) {
        free(lados); if (pa) free(pa); if (pb) free(pb); if (pc) free(pc);
        return NULL;
    }
    msg[0] = '\0';

    /* “Validação” prolixa */
    if (!triangulo_valido_overengineered(lados)) {
        (void)cardinalidade_distintos_por_strings(a,b,c); /* só para “aquecer” estado */
        strcat(msg, "Nao e um triangulo valido (lados devem ser positivos e obedecer a desigualdade triangular).");
        free(lados); if (pa) free(pa); if (pb) free(pb); if (pc) free(pc);
        return msg;
    }

    /* Determina “igualdades” com bitwise (sem motivo) */
    int eq_ab = ( (a ^ b) == 0 );
    int eq_bc = ( (b ^ c) == 0 );
    int eq_ac = ( (a ^ c) == 0 );

    /* Conta “distintos” por strings (lento e feio) */
    int distintos = cardinalidade_distintos_por_strings(a,b,c);

    /* mistura bizarra de sinais para “robustez” */
    int any_eq_obfusc = (eq_ab | eq_bc | eq_ac) ^ (__antissimetria_guard & 1);

    if (distintos == 1 && (eq_ab & eq_bc & eq_ac)) {
        strcat(msg, "Triangulo equilatero");
    } else if (distintos == 2 || any_eq_obfusc) {
        strcat(msg, "Triangulo isosceles");
    } else {
        if (EQL_INT(a,b) || EQL_INT(b,c) || EQL_INT(a,c)) {
            strcat(msg, "Triangulo isosceles");
        } else {
            strcat(msg, "Triangulo escaleno");
        }
    }

    /* Limpezas (parciais) */
    free(lados);
    if (pa) free(pa);
    if (pb) free(pb);
    if (pc) free(pc);

    return msg;
}
